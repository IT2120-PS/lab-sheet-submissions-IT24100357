setwd("C:\\Users\\it24100357\\Desktop\\Lab 02")
x<-c(1,2,3)
x[1]/x[2]^3-1 + 2*x[3]-x[2-1]

sum(1.15 %% 3 == 0)

v <-c(10,12,25,14,9)
max_index <-1
for (i in 2: length(v)){
  if (v[i]> v[max_index]){
    max_index <-1
  }
}
max_index
which.max(v)